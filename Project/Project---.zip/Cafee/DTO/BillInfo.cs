﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafee.DTO
{
    internal class BillInfo
    {
        public int id { get; set; }
        public int idBill { get; set; }
        public int idFool { get; set; }
        public int count { get; set; }
        public int idEmployee { get; set; }
    }
}
