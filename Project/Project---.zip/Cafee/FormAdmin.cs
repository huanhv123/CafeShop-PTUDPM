﻿using Cafee.DAO;
using Cafee.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Cafee.BUS;
namespace Cafee
{
    public partial class FormAdmin : Form
    {
        public FormAdmin()
        {
            InitializeComponent();
            //LoadAccountList();
            cbTypeAcount.Items.Add("1");
            cbTypeAcount.Items.Add("0");
            Form();
        }
        private void btnShowAccount_Click(object sender, EventArgs e)
        {
            //string query = "select * from Account where id=1";
            //DataProvider provider = new DataProvider();
            //DataTable acountData = provider.ExecuteQuery(query);
            //foreach ( DataRow acount in acountData.Rows)
            //{
            //    txtAccountUserName = acountData["UserName"].ToString();
            //}
        }

        private void dagvAccount_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvAccount.SelectedRows.Count > 0)
            {
                int ID = int.Parse(dgvAccount.SelectedRows[0].Cells["ID"].Value.ToString());
                Account account = AccountBUS.Instance.GetDetail(ID);
                if (account != null)
                {
                    txtAccountUserName.Text = account.username;
                    txtDisplayName.Text = account.displayName;
                    cbTypeAcount.Text = account.type.ToString();
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("ARE YOU SURE ?", "CONFIRMATION", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                int ID = int.Parse(dgvAccount.SelectedRows[0].Cells["ID"].Value.ToString());
                bool result = AccountBUS.Instance.Delete(ID);
                if (result)
                {
                    Form();
                }
                else
                {
                    MessageBox.Show("Delet Fail!");
                }
            }
        }
        private void Form()
        {
            List<Account> accounts = AccountBUS.Instance.GetAllAccount();
            dgvAccount.DataSource = accounts;
            dgvAccount.Columns["password"].Visible = false;
        }
        private void FormAdmin_Load(object sender, EventArgs e)
        {
            Form();
        }
        private void btn_update_Click(object sender, EventArgs e)
        {
            Account account = new Account()
            {
                id = int.Parse(dgvAccount.SelectedRows[0].Cells["ID"].Value.ToString()),
                username = txtAccountUserName.Text,
                displayName = txtDisplayName.Text,
                type = cbTypeAcount.SelectedIndex,
            };
            bool result = AccountBUS.Instance.Update(account);
            if (result)
            {
                Form();
            }
            else
            {
                MessageBox.Show("Update Fail!");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddAccount addAccount = new AddAccount();
            addAccount.ShowDialog();
            Form();
        }

    }
}
